package com.trivediCamp1.root;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Personalization {
	@JsonProperty("x-apiheader") 
	private String xApiheader;
    public String getxApiheader() {
		return xApiheader;
	}
	public void setxApiheader(String xApiheader) {
		this.xApiheader = xApiheader;
	}
	public String getRecipient() {
		return recipient;
	}
	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}
	public Personalization() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Personalization(String xApiheader, String recipient) {
		super();
		this.xApiheader = xApiheader;
		this.recipient = recipient;
	}
	private String recipient;
}
