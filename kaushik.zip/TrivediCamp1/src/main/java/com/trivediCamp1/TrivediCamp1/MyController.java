package com.trivediCamp1.TrivediCamp1;

import java.util.Optional;
import java.util.regex.Pattern;

import javax.sound.midi.Soundbank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@Autowired
	private kafkaData object;

	@PostMapping("/data")
	public ResponseEntity<String> addDataToKafk(@RequestBody Kafka obj) {
		
		boolean emailValidation = this.object.isValidEmail(obj.getMail());
		boolean numberValidation = this.object.isValidNumber(obj.getContact());

		if (!emailValidation || !numberValidation) {

			HttpHeaders header = new HttpHeaders();
			if (!emailValidation && !numberValidation) {
				header.add("Rejected", "Please enter the valid Email and Contact Number");
			} else if (!emailValidation) {
				header.add("Rejected", "Please enter the valid Email address");
			} else {
				header.add("Rejected", "Please enter the valid Contact Number");
			}

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(header).body("Error");

		} else {
			this.object.addObjectToKafka(obj);

			HttpHeaders header = new HttpHeaders();
			header.add("Congrats", "You have successfully inserted the data");
			return ResponseEntity.status(HttpStatus.ACCEPTED).headers(header).body("Success");
		}

	}

	// **************************************

	@PostMapping("/index")
	public ResponseEntity<String> addDataToKafk(@RequestBody Root obj) {

		boolean emailValidation = this.object.isValidEmail(obj.getFrom().getFromEmail());

		if (!emailValidation) {

			HttpHeaders header = new HttpHeaders();

			header.add("Rejected", "Please enter the valid Email address");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(header).body("Error");

		} else {
			this.object.addObjectToKafka2(obj);
			
			HttpHeaders header = new HttpHeaders();
			header.add("Congrats", "You have successfully inserted the data");
			return ResponseEntity.status(HttpStatus.ACCEPTED).headers(header).body("Success");
		}

	}

	@PostMapping("/home")
	public ResponseEntity<String> addDataToKafk(@RequestBody MyClass obj) {

		boolean emailValidation = this.object.isValidEmail(obj.getEmail());

		System.out.println("Home && email " + emailValidation);
		if (!emailValidation) {

			HttpHeaders header = new HttpHeaders();

			header.add("Rejected", "Please enter the valid Email address");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(header).body("Error");

		} else {
			this.object.addObjectToKafka3(obj);

			HttpHeaders header = new HttpHeaders();
			header.add("Congrats", "You have successfully inserted the data");
			return ResponseEntity.status(HttpStatus.ACCEPTED).headers(header).body("Sussess");
		}

	}

}
