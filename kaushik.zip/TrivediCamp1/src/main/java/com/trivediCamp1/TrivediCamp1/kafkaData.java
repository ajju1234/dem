package com.trivediCamp1.TrivediCamp1;

import java.util.List;

public interface kafkaData {

	public boolean isValidEmail(String Email);

	public boolean isValidNumber(String number);
	
	public void addObjectToKafka(Kafka obj);
	
	public void addObjectToKafka2(Root obj);
	
	public void addObjectToKafka3(MyClass obj);
}
