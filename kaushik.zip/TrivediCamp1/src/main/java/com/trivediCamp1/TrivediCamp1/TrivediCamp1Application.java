package com.trivediCamp1.TrivediCamp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrivediCamp1Application {

	public static void main(String[] args) {
		SpringApplication.run(TrivediCamp1Application.class, args);
	}

}
