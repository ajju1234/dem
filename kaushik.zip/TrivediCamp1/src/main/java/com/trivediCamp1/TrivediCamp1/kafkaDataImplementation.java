package com.trivediCamp1.TrivediCamp1;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.stereotype.Service;

//import com.fasterxml.jackson.databind.ser.std.StringSerializer;

@Service
public class kafkaDataImplementation implements kafkaData {

	@Override
	public boolean isValidEmail(String Email) {
		System.out.println("call from home "+Email);
		if (Email==null||Email.length()==0)
			return false;
		String regexString = "^([\\w-\\.]+){1,64}@([\\w&&[^_]]+){2,255}.[a-z]{2,}$";
		Pattern pattern = Pattern.compile(regexString);
		if (pattern.matcher(Email).matches()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean isValidNumber(String number) {
		System.out.println("number " + number);
		if (number.length() == 10) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void addObjectToKafka(Kafka obj) {
		Properties properties = new Properties();

		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		
		KafkaProducer<String,Kafka> producer=new KafkaProducer<String,Kafka>(properties);
		ProducerRecord<String,Kafka> record=new ProducerRecord<String,Kafka>("triVedi",obj.getMail(),obj);
		producer.send(record, (metadata, exception) -> {
		      if (exception != null) {
                       System.out.println("Error");
                       System.out.println(exception.getMessage());
		      }
		      else {
		    	  System.out.println("working");
		      }
	});
				//producer.send(record);
				producer.close();
				
	}
	
	  @Override public void addObjectToKafka2(Root obj) { 
		
	  Properties properties = new Properties();

		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		
		KafkaProducer<String,Root> producer=new KafkaProducer<String,Root>(properties);
		ProducerRecord<String,Root> record=new ProducerRecord<String,Root>("triVedi",obj.getFrom().getFromEmail(),obj);
		producer.send(record, (metadata, exception) -> {
		      if (exception != null) {
                       System.out.println("Error");
                       System.out.println(exception.getMessage());
		      }
		      else {
		    	  System.out.println("working");
		      }
	});
				//producer.send(record);
				producer.close();
	  }

	@Override
	public void addObjectToKafka3(MyClass obj) {
		Properties properties = new Properties();

		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		
		KafkaProducer<String,MyClass> producer=new KafkaProducer<String,MyClass>(properties);
		ProducerRecord<String,MyClass> record=new ProducerRecord<String,MyClass>("triVedi",obj.getEmail(),obj);
		producer.send(record, (metadata, exception) -> {
		      if (exception != null) {
                       
                       System.out.println(exception.getMessage());
		      }
		      
	});
				//producer.send(record);
				producer.close();
		
	}
	 

	
}
