package com.trivediCamp1.TrivediCamp1;

public class MyClass {
    private String email;
    private String content;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public MyClass(String email, String content) {
		super();
		this.email = email;
		this.content = content;
	}
	public MyClass() {
		super();
		// TODO Auto-generated constructor stub
	}
}
