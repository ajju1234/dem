package com.trivediCamp1.TrivediCamp1;

import java.util.List;

public class Root {
	 private List<Personalization> personalizations;
	  private String subject;
	    private From from;
	    private String content;
		public List<Personalization> getPersonalizations() {
			return personalizations;
		}
		public void setPersonalizations(List<Personalization> personalizations) {
			this.personalizations = personalizations;
		}
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public From getFrom() {
			return from;
		}
		public void setFrom(From from) {
			this.from = from;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public Root() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Root(List<Personalization> personalizations, String subject, From from, String content) {
			super();
			this.personalizations = personalizations;
			this.subject = subject;
			this.from = from;
			this.content = content;
		}
}
