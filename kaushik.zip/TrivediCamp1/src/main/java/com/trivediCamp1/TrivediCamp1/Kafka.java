package com.trivediCamp1.TrivediCamp1;

public class Kafka {
	private String mail;
	private String name;
	private String contact;
	private String occasion;

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getOccasion() {
		return occasion;
	}

	public void setOccasion(String occasion) {
		this.occasion = occasion;
	}

	public Kafka(String mail, String name, String contact, String occasion) {
		super();
		this.mail = mail;
		this.name = name;
		this.contact = contact;
		this.occasion = occasion;
	}

	public Kafka() {
		super();

	}

}
